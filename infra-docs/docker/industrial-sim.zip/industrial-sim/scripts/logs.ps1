docker compose logs -f
