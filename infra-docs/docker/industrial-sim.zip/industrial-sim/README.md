# Industrial Protocol Simulators

Simuladores Docker independentes para uma mesma planta: Modbus TCP, Modbus RTU, Siemens S7 e OPC-UA.

## Executar

```powershell
docker compose build
docker compose up -d
docker compose ps
```

Endpoints:

- Modbus TCP: `localhost:502`
- S7: `localhost:1102`
- OPC-UA: `opc.tcp://localhost:4840/freeopcua/server/`
- Modbus RTU: serial virtual interna do container (`/run/rtu/ttyV0`)

Guia Docusaurus: `docs/industrial-sim.md`.

## Parar

```powershell
docker compose down
```

> RTU é serial. Neste pacote o par virtual fica dentro do container para evitar dependência de COM/RS-485 no host.
