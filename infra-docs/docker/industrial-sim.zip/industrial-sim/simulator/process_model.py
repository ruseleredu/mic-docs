import math, threading, time
LOCK=threading.Lock()
state={"level":65.0,"temperature":27.0,"pressure":2.1,"speed":72.0,"running":True}
def snapshot():
    with LOCK: return dict(state)
def update_loop():
    start=time.monotonic()
    while True:
        t=time.monotonic()-start
        with LOCK:
            state["level"]=65+20*math.sin(t/60*2*math.pi)
            state["temperature"]=27+3*math.sin(t/45*2*math.pi)
            state["pressure"]=2+.2*math.sin(t/30*2*math.pi)
            state["speed"]=(70+10*math.sin(t/20*2*math.pi)) if state["running"] else 0
        time.sleep(1)
