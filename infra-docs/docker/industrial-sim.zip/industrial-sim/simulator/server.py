import asyncio,logging,struct,sys,threading,time,os,subprocess
from process_model import snapshot,update_loop
logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s")

def run_modbus_tcp():
    from pymodbus.datastore import ModbusDeviceContext,ModbusSequentialDataBlock,ModbusServerContext
    from pymodbus.server import StartTcpServer
    hr=ModbusSequentialDataBlock(0,[0]*20); co=ModbusSequentialDataBlock(0,[0]*20)
    ctx=ModbusServerContext(devices=ModbusDeviceContext(hr=hr,co=co),single=True)
    def update():
        while True:
            s=snapshot(); hr.setValues(0,[int(s["level"]*10),int(s["temperature"]*10),int(s["pressure"]*10),int(s["speed"]*10)])
            co.setValues(0,[int(s["running"]),int(s["running"])]); time.sleep(1)
    threading.Thread(target=update,daemon=True).start()
    logging.info("Modbus TCP: 0.0.0.0:502")
    StartTcpServer(context=ctx,address=("0.0.0.0",502))

def make_rtu_pair():
    os.makedirs("/run/rtu",exist_ok=True)
    for p in ("/run/rtu/ttyV0","/run/rtu/ttyV1"):
        try: os.unlink(p)
        except FileNotFoundError: pass
    p=subprocess.Popen(["socat","-d","-d","PTY,link=/run/rtu/ttyV0,raw,echo=0,waitslave","PTY,link=/run/rtu/ttyV1,raw,echo=0,waitslave"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for _ in range(50):
        if all(os.path.exists(x) for x in ("/run/rtu/ttyV0","/run/rtu/ttyV1")):
            logging.info("Modbus RTU virtual pair: ttyV0 <-> ttyV1"); return p
        time.sleep(.1)
    p.terminate(); raise RuntimeError("Could not create virtual serial pair")

def run_modbus_rtu():
    from pymodbus.datastore import ModbusDeviceContext,ModbusSequentialDataBlock,ModbusServerContext
    from pymodbus.server import StartSerialServer
    from pymodbus.framer import FramerType
    make_rtu_pair()
    hr=ModbusSequentialDataBlock(0,[0]*20); co=ModbusSequentialDataBlock(0,[0]*20)
    ctx=ModbusServerContext(devices=ModbusDeviceContext(hr=hr,co=co),single=True)
    def update():
        while True:
            s=snapshot(); hr.setValues(0,[int(s["level"]*10),int(s["temperature"]*10),int(s["pressure"]*10),int(s["speed"]*10)])
            co.setValues(0,[int(s["running"]),int(s["running"])]); time.sleep(1)
    threading.Thread(target=update,daemon=True).start()
    logging.info("Modbus RTU: /run/rtu/ttyV0, 9600 8N1, unit 1")
    StartSerialServer(context=ctx,framer=FramerType.RTU,port="/run/rtu/ttyV0",baudrate=9600,bytesize=8,parity="N",stopbits=1,timeout=1)

def run_s7():
    from snap7.server import Server,SrvArea
    db=bytearray(32); server=Server(); server.register_area(SrvArea.DB,1,db)
    def update():
        while True:
            s=snapshot()
            db[0:4]=struct.pack(">f",s["level"]); db[4:8]=struct.pack(">f",s["temperature"])
            db[8:12]=struct.pack(">f",s["pressure"]); db[12:16]=struct.pack(">f",s["speed"])
            db[16]=3 if s["running"] else 0; time.sleep(1)
    threading.Thread(target=update,daemon=True).start()
    logging.info("S7: 0.0.0.0:1102 / DB1"); server.start(tcp_port=1102)
    try:
        while True: time.sleep(3600)
    finally: server.stop()

async def run_opcua_async():
    from asyncua import Server
    server=Server(); await server.init()
    server.set_endpoint("opc.tcp://0.0.0.0:4840/freeopcua/server/")
    idx=await server.register_namespace("urn:industrial-sim")
    plant=await server.nodes.objects.add_object(idx,"Plant")
    tank=await plant.add_object(idx,"Tank"); pump=await plant.add_object(idx,"Pump")
    level=await tank.add_variable(idx,"Level",65.0); temp=await tank.add_variable(idx,"Temperature",27.0)
    pressure=await tank.add_variable(idx,"Pressure",2.1); running=await pump.add_variable(idx,"Running",True)
    speed=await pump.add_variable(idx,"Speed",72.0)
    for n in (level,temp,pressure,running,speed): await n.set_writable()
    logging.info("OPC-UA: opc.tcp://0.0.0.0:4840/freeopcua/server/")
    async with server:
        while True:
            s=snapshot()
            await level.write_value(float(s["level"])); await temp.write_value(float(s["temperature"]))
            await pressure.write_value(float(s["pressure"])); await running.write_value(bool(s["running"]))
            await speed.write_value(float(s["speed"])); await asyncio.sleep(1)

def run_opcua(): asyncio.run(run_opcua_async())

def run_rtu_test():
    import os
    from pymodbus.client import ModbusSerialClient
    port="/run/rtu/ttyV1"
    if not os.path.exists(port): raise RuntimeError("ttyV1 is not available; start modbus-rtu first")
    c=ModbusSerialClient(port=port,baudrate=9600,bytesize=8,parity="N",stopbits=1,timeout=1)
    if not c.connect(): raise RuntimeError("RTU client connection failed")
    try:
        r=c.read_holding_registers(address=0,count=4,device_id=1)
        logging.info("RTU registers: %s",r.registers if not r.isError() else r)
    finally: c.close()

def main():
    choices={"modbus-tcp":run_modbus_tcp,"modbus-rtu":run_modbus_rtu,"s7":run_s7,"opcua":run_opcua,"rtu-test":run_rtu_test}
    if len(sys.argv)!=2 or sys.argv[1] not in choices: raise SystemExit("server.py modbus-tcp|modbus-rtu|s7|opcua|rtu-test")
    threading.Thread(target=update_loop,daemon=True).start(); choices[sys.argv[1]]()
if __name__=="__main__": main()
